package com.example.serviceTest;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.baseTest.SpringTestCase;
import com.example.domain.Admin;
import com.example.service.AdminService;

public  class AdminServiceTest extends SpringTestCase{
	 Logger logger = LoggerFactory.getLogger(this.getClass());
	    @Autowired  
	    private AdminService adminService; 
//	    @Test  
//	    public void selectUserByIdTest(){  
//	        Admin admin = adminService.selectAdminById(1);  
//	        logger.info("查找结果" + admin);  
//	    }  
}
