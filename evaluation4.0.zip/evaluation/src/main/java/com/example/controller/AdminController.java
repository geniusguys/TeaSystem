package com.example.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.Admin;
import com.example.result.Result;
import com.example.service.AdminService;
import com.google.gson.Gson;
/**
 * 
 * @author genius
 * @Date 2019-9-18 11:00
 * @describe 管理员控制层
 */
@RestController
@RequestMapping("/api")
public class AdminController {

	@Autowired
	private AdminService adminService;
	
	Gson gson=new Gson();
	/**
	 * @describe 根据管理ID查询管理员信息
	 * @param adminId
	 * @return 返回一条字符串信息
	 */
		//	@RequestMapping("getAdmin/{adminId}")
		//	@RequestMapping(value = "getAdmin/{adminId}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
		//	public String GetAdmin(@PathVariable Integer adminId) {
		//		return adminService.selectAdminById(adminId).toString();
		//		
		//	}
	
	 	/**
		 * @describe 查询所有管理员信息
		 * @param null
		 * @return 返回一条字符串信息
		 */
	 	@RequestMapping(value = "/admins", method = RequestMethod.GET)
		public Result GetAdmin() {
			
			return adminService.selectAdmin();
			
		}
		
		/**
		 * @describe 添加管理员信息
		 * @param admin
		 * @return
		 */
	 	@RequestMapping(value = "/admins", method = RequestMethod.POST)
		public Result insertAdmin(@RequestBody String json) {
			
			Admin admin=gson.fromJson(json, Admin.class);
			
	 		return adminService.insertAdmin(admin);	
		}
	 	
		
		/**
		 * @describe 根据管理员ID删除管理员
		 * @param adminId
		 * @return
		 */
	 	@RequestMapping(value = "/admins/{adminId}", method = RequestMethod.DELETE)
		public Result delAdmin(@PathVariable("adminId") String adminId) {
			System.out.println("管理员ID=============="+adminId);

			return adminService.delAdmin(Integer.parseInt(adminId));
		}
		
		/**
		 * @describe 查看管理员信息
		 * @param adminId
		 * @param admin
		 * @param model
		 * @return
		 */
	 	@RequestMapping(value = "/admins/{adminId}", method = RequestMethod.GET)
		public Result lookAdmin(@PathVariable("adminId") String adminId) {
			System.out.println("管理员ID=============="+adminId);
			
			return adminService.lookAdmin(Integer.parseInt(adminId));
		}
		
		/**
		 * @describe 修改管理员信息
		 * @param admin
		 * @param model
		 * @return 返回查看页面
		 */
	 	@RequestMapping(value = "/admins", method = RequestMethod.PUT)
		public Result updateAdmin(@RequestBody String json) {
			
			Admin admin=gson.fromJson(json, Admin.class);
			
			return adminService.updateAdmin(admin);
		}

}
