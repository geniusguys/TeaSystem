package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.AssigningCourse;
import com.example.domain.Course;
import com.example.domain.Term;
import com.example.result.Result;
import com.example.service.CommonService;
import com.google.gson.Gson;
/**
 * @describe 公共控制层
 * @author genius
 * @Date 2019-9-22 20:24
 */
@RestController
@RequestMapping("/api")
public class CommonController {
 
	@Autowired
	private CommonService commonService;
	
	Gson gson=new Gson();
	
	/**
	 * @describe 添加学期信息到数据库
	 * @param term
	 * @return 成功显示学期信息，添加失败则弹出错误提示！
	 */
	@RequestMapping(value="/terms",method = RequestMethod.POST)
	public Result insertTerm(@RequestBody String json) {
		
		Term term=gson.fromJson(json, Term.class);
		
		return commonService.insertTerm(term);		
	}
	
	/**
	 * @describe 查询全部学期信息
	 * @param model
	 * @return 返回一个学期列表信息
	 */
	@RequestMapping(value="/terms",method = RequestMethod.GET)
	public Result queryAllTerm() {
		
		return commonService.queryAllTerm();
	}
	
	/**
	 * @describe 根据学期ID删除学期信息
	 * @param termId
	 * @return 成功返回学期列表并提示成功信息，反之弹出失败提示信息
	 */
	@RequestMapping(value="/terms/{termId}",method = RequestMethod.DELETE)
	public Result delTerm(@PathVariable("termId") String termId) {
		System.out.println("学期ID=============="+termId);

		return commonService.delTerm(Integer.parseInt(termId));
	}
	
	/**
	 * @describe 根据学期ID查看学期信息
	 * @param termId
	 * @return 成功则显示学期信息，反之弹出失败提示信息
	 */
	@RequestMapping(value="/terms/{termId}",method = RequestMethod.GET)
	public Result lookTermInfoById(@PathVariable("termId") String termId) {
		System.out.println("学期ID=============="+termId);
		
		return commonService.lookTermInfoById(Integer.parseInt(termId));
	}
	
	/**
	 * @describe 根据学期ID修改学期信息
	 * @return 修改成功则弹出成功提示框，反之弹出失败提示框
	 */
	@RequestMapping(value="/terms",method = RequestMethod.PUT)
	public Result updateTerm(@RequestBody String json) {
	
		Term term=gson.fromJson(json, Term.class);
		
		return commonService.updateTerm(term);
	}
	
	//============================课程类(Course)=======================================
	
	/**
	 * @describe 插入课程信息
	 * @param course
	 * @return 成功则弹出一个成功提示框，反之弹出一个错误提示框
	 */
	@RequestMapping(value="/courses",method = RequestMethod.POST)
	public Result insertCourse(@RequestBody String json) {
		
		Course course=gson.fromJson(json, Course.class);
		
		return commonService.insertCourse(course);				
	}
	
	/**
	 * @describe 查询全部课程信息
	 * @param null
	 * @return 返回一个课程列表信息
	 */
	@RequestMapping(value="/courses",method = RequestMethod.GET)
	public Result queryAllCourse() {
		
		return commonService.queryAllCourse();
	}
	
	/**
	 * @describe 根据课程ID查看课程信息
	 * @param courseId
	 * @return 成功则显示课程信息，反之弹出失败提示信息
	 */
	@RequestMapping(value="/courses/{courseId}",method = RequestMethod.GET)
	public Result lookCourseInfoById(@PathVariable("courseId") String courseId) {
		System.out.println("课程ID=============="+courseId);
		
		return commonService.lookCourseInfoById(Integer.parseInt(courseId));
	}
	
	/**
	 * @describe 根据课程ID删除课程信息
	 * @param courseId
	 * @return 成功返回提示成功信息，反之弹出失败提示信息
	 */
	@RequestMapping(value="/courses/{courseId}",method = RequestMethod.DELETE)
	public Result delCourse(@PathVariable("courseId") String courseId) {
		System.out.println("课程ID=============="+courseId);
	
		return commonService.delCourse(Integer.parseInt(courseId));
	}
	
	/**
	 * @describe 根据课程ID修改课程信息
	 * @param Course
	 * @return 修改成功则弹出成功提示框，反之弹出失败提示框
	 */
	@RequestMapping(value="/courses",method = RequestMethod.PUT)
	public Result updateCourse(@RequestBody String json) {
	
		Course course=gson.fromJson(json, Course.class);
		
		return commonService.updateCourse(course);
	}
	
	
	
	//=============================分配管理（apportion）============================
	
	/**
	 * @describe 根据学生ID和班级ID分配学生到班级
	 * @param studentId
	 * @param classId
	 * @return 分配成功则弹出成功提示信息，反之弹出失败信息
	 */
	@RequestMapping(value="/apportion/stu_to_class/{studentId}/{classId}",method = RequestMethod.PUT)
	public Result studentApportionClass(@PathVariable("studentId") String studentId,@PathVariable("classId") String classId) {
		
		return commonService.studentApportionClass(Integer.parseInt(studentId),Integer.parseInt(classId));
		
	}
	
	/**
	 * @describe 根据学生ID和院系ID分配学生到院系
	 * @param studentId
	 * @param dpId
	 * @return 分配成功则弹出成功提示信息，反之弹出失败信息
	 */
	@RequestMapping(value="/apportion/stu_to_departments/{studentId}/{dpId}",method = RequestMethod.PUT)
	public Result studentApportionDepartment(@PathVariable("studentId") String studentId,@PathVariable("dpId") String dpId) {
		
		return commonService.studentApportionDepartment(Integer.parseInt(studentId),Integer.parseInt(dpId));
		
	}
	
	/**
	 * @describe 根据班级ID和院系ID分配学生到院系
	 * @param classId
	 * @param dpId
	 * @return 分配成功则弹出成功提示信息，反之弹出失败信息
	 */
	@RequestMapping(value="/apportion/class_to_departments/{classId}/{dpId}",method = RequestMethod.PUT)
	public Result classApportionDepartment(@PathVariable("classId") String classId,@PathVariable("dpId") String dpId) {
		
		return commonService.classApportionDepartment(Integer.parseInt(classId),Integer.parseInt(dpId));
	}
	
	/**
	 * @describe 根据教师ID和院系ID分配教师到院系
	 * @param teacherId
	 * @param dpId
	 * @return 分配成功则弹出成功提示信息，反之弹出失败信息
	 */
	@RequestMapping(value="/apportion/class_to_departments/{teacherId}/{dpId}",method = RequestMethod.PUT)
	public Result teacherApportionDepartment(@PathVariable("teacherId") String teacherId,@PathVariable("dpId") String dpId) {
		
		return commonService.teacherApportionDepartment(Integer.parseInt(teacherId),Integer.parseInt(dpId));	
	}
	
	/**
	 * @describe 分配授课表信息
	 * @param json
	 * @return 分配成功则弹出成功提示信息，反之弹出失败信息
	 */
	@RequestMapping(value="/apportion/assigningCourses",method = RequestMethod.POST)
	public Result apportionAssigningCourse(@RequestBody String json) {
		
		AssigningCourse assigningCourse=gson.fromJson(json, AssigningCourse.class);
		
		return commonService.apportionAssigningCourse(assigningCourse);	
	}
	
	/**
	 * @describe 分配评教题目选项信息
	 * @param eqId
	 * @param esId
	 * @return 分配成功则弹出成功提示信息，反之弹出失败信息
	 */
	@RequestMapping(value="/apportion/questionSelects/{eqId}/{esId}",method = RequestMethod.PUT)
	public Result apportionQuestionSelect(@PathVariable("eqId") String eqId,@PathVariable("esId") String esId) {
		
		return commonService.apportionQuestionSelect(Integer.parseInt(eqId),Integer.parseInt(esId));	
	}
	
}
