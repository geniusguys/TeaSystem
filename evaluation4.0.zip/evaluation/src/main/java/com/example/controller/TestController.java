package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.result.Result;
import com.example.service.AdminService;

/**
 * 
 * @author genius
 * @Date 2019-9-19 9:14
 * @describe 测试控制层
 */
@Controller
public class TestController {
	
	@Autowired
	private AdminService adminService;
	
	 @RequestMapping("/test")
	    public ModelAndView test(ModelAndView modelAndView) {
	        modelAndView.addObject("hello","这是我第一个使用Thymelead的页面！");
	        modelAndView.setViewName("test");
	        return modelAndView;
	    }
	 
	 /**
	  *      跳转主页面
	  * @return
	  */
	 @RequestMapping("/index")
		public String Index() {
			return "Index";
		}
	 
	 	/**
		 * @describe 查询管理员信息
		 * @param null
		 * @return 返回一条字符串信息
		 */
//		@RequestMapping("/allAdmin")
//		public String GetAdmin(Model model) {
//			List<Admin> list=adminService.selectAdmin();
//			model.addAttribute("adminList", list);
//			return "showAdmin";
//			
//		}
	 
	 /**
		 * @describe 查询管理员信息
		 * @param null
		 * @return 返回一条字符串信息
		 */
		@RequestMapping("/allAdmin")
		@ResponseBody
		public Result GetAdmin(Model model) {
//			List<Admin> list=adminService.selectAdmin();
			return adminService.selectAdmin();
			
		}
		
		
		/**
		 * @describe 添加管理员信息
		 * @param admin
		 * @return
		 */
//		@RequestMapping("/insertAdmin")
//		public String insertAdmin(Admin admin) {
//			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//			admin.setRecordTime(df.format(new Date()));
//			int row=adminService.insertAdmin(admin);
//			return "insertAdmin";
//		}
		
		/**
		 * @describe 根据管理员ID删除管理员
		 * @param adminId
		 * @return
		 */
//		@RequestMapping("/delAdmin")
//		public String delAdmin(@RequestParam String adminId,Model model) {
//			System.out.println("管理员ID=============="+adminId);
//			int row=adminService.delAdmin(Integer.parseInt(adminId));
//			if(row>0) {
//				List<Admin> list=adminService.selectAdmin();
//				model.addAttribute("adminList", list);
//			}
//			
//			return "showAdmin";
//		}
		
		/**
		 * @describe 查看管理员信息
		 * @param adminId
		 * @param admin
		 * @param model
		 * @return
		 */
//		@RequestMapping("/queryAdmin")
//		public String lookAdmin(@RequestParam String adminId,Admin admin,Model model) {
//			System.out.println("管理员ID=============="+adminId);
//			admin.setAdminId(Integer.parseInt(adminId));
//			List<Admin> list=adminService.lookAdmin(Integer.parseInt(adminId));
//			admin=list.get(0);
//			System.out.println("管理员ID"+admin.getAdminId());
//			//System.out.println(list.toString());
//			model.addAttribute("adminInfo", admin);
//			return "lookAdmin";
//		}
		
		/**
		 * @describe 修改管理员信息
		 * @param admin
		 * @param model
		 * @return 返回查看页面
		 */
//		@RequestMapping("/updateAdmin")
//		public String updateAdmin(Admin admin,Model model) {
//			System.out.println("管理员ID=============="+admin.getAdminId());
//			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//			admin.setRecordTime(df.format(new Date()));
//			
//			int row=adminService.updateAdmin(admin);
//			if(row>0) {
//			List<Admin> list1=adminService.lookAdmin(admin.getAdminId());
//			admin=list1.get(0);
//			}
//			model.addAttribute("adminInfo", admin);
//			List<Admin> list=adminService.selectAdmin();
//			model.addAttribute("adminList", list);
//			return "showAdmin";
//		}
		
		@RequestMapping("/addAdmin")
		public String addAdmin() {
			return "insertAdmin";
		}
}
