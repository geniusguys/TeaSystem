package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.Teacher;
import com.example.result.Result;
import com.example.service.TeacherService;
import com.google.gson.Gson;
/**
 * @describe 教师类控制层
 * @author 游中成
 * @date 2019年9月23日
 * 
 */
@RestController
@RequestMapping("/api")
public class TeacherController {

	@Autowired
	private TeacherService teacherService;
	
	Gson gson=new Gson();
	
	/**
	 * @describe 查询所有教师
	 * @return 教师列表
	 */
	@RequestMapping(value="/teachers", method = RequestMethod.GET)
	public Result getTeacher() {	//查询所有教师信息
		
		return teacherService.selectTeacher();
	}
	/**
	 * 
	 * @describe  添加教师
	 * @param json
	 * @return
	 */
	@RequestMapping(value = "/teachers", method = RequestMethod.POST)
	public Result addTeacher(@RequestBody String json) {	//添加教师信息
		Teacher teacher = gson.fromJson(json, Teacher.class);
		return teacherService.insertTeacher(teacher);
		
	}
	
	/**
	 * 
	 * @describe 根据教师ID删除教师信息
	 * @param teaId
	 * @return
	 */
	@RequestMapping(value = "/teachers/{teaId}", method = RequestMethod.DELETE)
	public Result delTeacher(@PathVariable("teaId") String teaId) {
		//System.out.println("教师ID=============="+teaId);
		return teacherService.delTeacher(Integer.parseInt(teaId));
	}
	
	
	/**
	 * 
	 * @describe 根据教师teaId查询教师信息
	 * @param teaId
	 * @return 一条教师信息
	 */
	  @RequestMapping(value = "/teachers/{teaId}", method =RequestMethod.GET) 
	  public Result selectTeacherById(@PathVariable("teaId") String teaId) { 
	  		return teacherService.selectTeacherById(teaId);
	  }
	  
 
	  /**
	   * 
	   * @describe  根据教师 teaId 修改教师信息
	   * @param json
	   * @return Result
	   */
	  @RequestMapping(value ="/teachers",method =RequestMethod.PUT )
	  public Result updateTeaInfoById(String json) {
		  
		  Teacher teacher = gson.fromJson(json, Teacher.class);
//		  Teacher teacher = new Teacher();
//		  teacher.setTeaId(10);teacher.setComment("毕业重庆医科大学临床医学院");teacher.setIsLeader("0");teacher.setTeaJobNumber("20190001");
//		  teacher.setTeaName("杨玉荣");teacher.setTeaPassword("123456");teacher.setTeaSex("0");teacher.setTeaStatus("1");
//		  teacher.setDpId(3);
		return teacherService.updateTeaInfoById(teacher);
		  
	  }
	 
	
	
}
