package com.example.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
/**
 * 
 * @author genius
 * @Date 2019-9-17 11:00
 * @describe HelloWorld控制层
 */
@RestController
public class HelloWorldController {

	/**
	 * @describe SpringBoot环境搭建测试方法 
	 * @return 返回一个字符串信息
	 */
	@RequestMapping("/hello")
	public String welcom() {
		
		return "Hello! Welcome Genius come to SpringBoot World!";
	}
}
