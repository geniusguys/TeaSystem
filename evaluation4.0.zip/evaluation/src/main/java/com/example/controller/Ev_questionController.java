package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.Classes;
import com.example.domain.Ev_question;
import com.example.result.Result;
import com.example.service.Ev_questionService;
import com.google.gson.Gson;
/**
 * 
 * @ClassName: Ev_questionController
 * @Description: TODO(学生,老师题库选项表Controller)
 * @author 郭海滨
 * @date 2019年9月25日
 *
 */
@RestController
@RequestMapping("/api")
public class Ev_questionController {

	@Autowired
	private Ev_questionService evq;
	
	Gson gson = new Gson();
	
	/**
	 * 
	 * @Title: GetEv_question
	 * @Description: TODO(定义查询所有题目的类)
	 * @param @param Model
	 */
	@RequestMapping(value ="/evq",method = RequestMethod.GET)
	public Result GetEv_question(Model Model) {
		System.out.println("查询所有题目");
		return evq.selectEv_q();
	}
	
	/**
	 * 
	 * @Title: GetEv_question_sById
	 * @Description: TODO(查询单个题目与选项)
	 * @param @param eqId
	 */
	
	@RequestMapping(value ="/evq_s/{eqId}",method = RequestMethod.GET)
	public Result GetEv_question_sById(@PathVariable("eqId") String eqId) {
		System.out.println("查询单个题目与选项");
		return evq.select_allById(Integer.parseInt(eqId));
	}
	
	/**
	 * 
	 * @Title: GetEv_question_sAll
	 * @Description: TODO(查询所有题目与选项)
	 * @param @param Model
	 */
	@RequestMapping(value ="/evq_s",method = RequestMethod.GET)
	public Result GetEv_question_sAll(Model Model) {
		System.out.println("查询全部题目与选项");
		return evq.select_all();
	}
	
	/**
	 * 
	 * @Title: GetEv_question_order
	 * @Description: TODO(查询2个同类型的题目和选项   (mapper里面可以更改个数))
	 * @param @param eqType
	 * 用于生成随机试卷
	 */
	@RequestMapping(value ="/evq_s/tp/{eqType}",method = RequestMethod.GET)
	public Result GetEv_question_order(@PathVariable("eqType") String eqType) {
		System.out.println("查询固定个数随机的题目与选项");
		return evq.select_order(eqType);
	}
	
	
	/**
	 * 
	 * @Title: GetEv_questionById
	 * @Description: TODO(通过题号查询题目详情)
	 * @param @param eqId
	 * @throws
	 */
	@RequestMapping(value ="/evq/{eqId}",method = RequestMethod.GET)
	public Result GetEv_questionById(@PathVariable("eqId") String eqId) {
		System.out.println("查询单个题目号为"+eqId+"的信息");
		return evq.selectEv_qById(Integer.parseInt(eqId));
	}
	
	/**
	 * 
	 * @Title: GetEv_questionByTp
	 * @Description: TODO(分类查询所有题目)
	 * @param @param eqType
	 * @throws
	 */
	
	@RequestMapping(value ="/evq/type/{eqType}",method = RequestMethod.GET)
	public Result GetEv_questionByTp(@PathVariable("eqType") String eqType) {
		System.out.println("查询题目类型号为"+eqType+"的全部题目");
		return evq.selectEv_qByTp(Integer.parseInt(eqType));
	}
	
	
	
	
	/**
	 * 
	 * @Title: DELETEEv_questionById
	 * @Description: TODO(通过题号删除题目)
	 * @param @param eqId
	 * @throws
	 */
	@RequestMapping(value = "/evq/{eqId}" ,method=RequestMethod.DELETE)
	public Result DELETEEv_questionById(@PathVariable("eqId") String eqId) {
		System.out.println("删除题目号为"+eqId+"的信息");
		return evq.deleteEv_qById(Integer.parseInt(eqId));
	}
	
	/**
	 * 
	 * @Title: PUTEv_question
	 * @Description: TODO(修改题目信息)
	 * @param @param json
	 */
	
	@RequestMapping(value = "/evq" ,method=RequestMethod.PUT)
	public Result PUTEv_question(@RequestBody String json) {
		Ev_question evqtion = gson.fromJson(json,Ev_question.class );
		System.out.println("修改单个题目");
		return evq.updateEv_qById(evqtion);
	}
	
	/**
	 * 
	 * @Title: POSTEv_question
	 * @Description: TODO(插入单个题目)
	 * @param @param json
	 * @throws
	 */
	
	@RequestMapping(value = "/evq" ,method=RequestMethod.POST)
	public Result POSTEv_question(@RequestBody String json) {
		Ev_question evqtion = gson.fromJson(json,Ev_question.class );
		System.out.println("插入单个题目");
		return evq.insertEv_q(evqtion);
	}
	
	
	
}
