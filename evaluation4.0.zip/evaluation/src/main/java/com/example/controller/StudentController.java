package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.Student;
import com.example.result.Result;
import com.example.service.StudentService;
import com.google.gson.Gson;

/**
 * @describe 学生控制层
 * @author 郭海滨
 * @Date 2019-9-18 11:57
 */

@RestController
@RequestMapping("/api")
public class StudentController {

	@Autowired
	private StudentService studentService;

	/**
	 * @author 郭海滨
	 * @date 2019年9月23日
	 * @describe :gson
	 */
	Gson gson = new Gson();

	/**
	 * @author 郭海滨
	 * @date 2019年9月23日
	 * @return :返回多条字符串
	 */
	@RequestMapping(value = "/students", method = RequestMethod.GET)
	public Result GetStudent(Model model) {
		return studentService.selectStudent();
	}
	
	/**
	 * 
	 * @Title: GetStudent
	 * @Description: TODO(通过id查询学生信息)
	 * @param @param stuId
	 * @param @return 单个学生信息
	 * @return Result 返回类型
	 * @throws
	 */
	@RequestMapping(value = "/students/{stuId}", method = RequestMethod.GET)
	public Result GetStudent(@PathVariable("stuId") String stuId) {
		System.out.println("学生Id========"+stuId);
		return studentService.selectStudentById(Integer.parseInt(stuId));
	}
	
	
	/**
	 * 
	 * @Title: updateStu
	 * @Description: TODO(修改学生信息)
	 * @param @param json
	 * @param @return 参数
	 * @return Result 返回类型
	 * @throws
	 */
	@RequestMapping(value = "/students", method =  RequestMethod.PUT)
	public Result updateStu(@RequestBody String json) {
		Student student = gson.fromJson(json, Student.class);
		return  studentService.updateStudentById(student);
	}
	
	/**
	 * 
	 * @Title: insertStu
	 * @Description: TODO(插入一条新学生数据)
	 * @param @param json
	 * @param @return 参数
	 * @return Result 返回类型
	 * @throws
	 */
	
	@RequestMapping(value = "/students", method =  RequestMethod.POST)
	public Result insertStu(@RequestBody String json) {
		Student student = gson.fromJson(json, Student.class);
		return  studentService.insertStudentById(student);
	}

	/**
	 * 
	 * @Title: DeleteStu
	 * @Description: TODO(通过Id删除学生)
	 * @param @param stuId
	 * @param @return stuId
	 * @return Result int
	 * @throws
	 */
	@RequestMapping(value = "/students/{stuId}", method =  RequestMethod.DELETE)
	public Result DeleteStu(@PathVariable("stuId") String stuId) {
		System.out.println("删除学生编号"+stuId);
		return studentService.deleteStudentById(Integer.parseInt(stuId));
	}
}
