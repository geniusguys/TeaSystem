package com.example.controller;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.Department;
import com.example.result.Result;
import com.example.service.DepartmentService;
import com.google.gson.Gson;

/**
 * 
 * @author 游中成
 * @Date 2019-9-23 10.53
 * @describe 部门控制层
 */
@RestController
@RequestMapping("/api")
public class DepartmentController {
	
	@Autowired
	private DepartmentService departmentService;
	
	Gson gson = new Gson();
	
	/**
	 * @describe 查询所有部门信息
	 * @param Model model
	 * @return Result
	 */
	@RequestMapping(value="/departments",method = RequestMethod.GET)
	public Result getDepartment(Model model) { 
		return departmentService.selectDepartment();
	}
	
	/**
	 * @describe 添加部门信息
	 * @param String json
	 * @return Result
	 */
	@RequestMapping(value = "/departments",method = RequestMethod.POST )
	public Result insertDepartment(@RequestBody String json) {
		Department department = gson.fromJson(json, Department.class);
		return departmentService.insertDepartment(department);
		
	}


	/**
	 * 
	 * @describe 根据部门  dpId 删除部门信息
	 * @param String dpId
	 * @return Result
	 */
	@RequestMapping(value = "/departments/{dpId}", method = RequestMethod.DELETE)
	public Result deleteDepartment(@PathVariable("dpId") String dpId) {
		return departmentService.deleteDepartment(Integer.parseInt(dpId));
	}
	
	/**
	 * 
	 * @describe 根据部门  dpId 查询部门信息
	 * @param dpId
	 * @return Result
	 */
	@RequestMapping(value = "/departments/{dpId}", method = RequestMethod.GET)
	public Result selectDepartmentById(@PathVariable("dpId") String dpId) {
		return departmentService.selectDepartmentById(Integer.parseInt(dpId));
	}
	
	/**
	 * 
	 * @describe  修改部门信息
	 * @param dpId
	 * @return
	 */
	@RequestMapping(value = "/departments",method = RequestMethod.PUT)
	public Result updateDepartment(@RequestBody String json) {
		Department department  = gson.fromJson(json, Department.class);
		return departmentService.updateDepartment(department);
		
	}
	
	

}
