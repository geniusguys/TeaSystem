package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.Classes;
import com.example.result.Result;
import com.example.service.ClassesService;
import com.google.gson.Gson;

/**
 * 
 * @ClassName: ClassesController
 * @Description: TODO(班级控制层)
 * @author 郭海滨
 * @date 2019年9月24日
 *
 */

@RestController
@RequestMapping("/api")
public class ClassesController {
	
	@Autowired
	private ClassesService  classervice;
	
	
	Gson gson = new Gson();
	
	/**
	 * 
	 * @Title: GetClass
	 * @Description: TODO(定义查询全部班级)
	 * @param @param model
	 * @param @return selectClass
	 * @return Result list
	 * @throws
	 */
	@RequestMapping(value = "/classes" ,method=RequestMethod.GET)
	public Result GetClass(Model model) {
		return classervice.selectClass();
	}
	
	/**
	 * 
	 * @Title: GetclassbyId
	 * @Description: TODO(定义查询单个班级)
	 * @param @param classId
	 * @throws
	 */
	@RequestMapping(value = "/classes/clas/{classId}" ,method=RequestMethod.GET)
	public Result GetclassbyId(@PathVariable("classId") String classId) {
		System.out.println("查询班级号为========"+classId+"的班级信息");
		return classervice.selectClassById(Integer.parseInt(classId));
	}
	
	/**
	 * 
	 * @Title: GetclassdpId
	 * @Description: TODO(定义查询同院系的多个班级)
	 * @param @param dpId
	 * @throws
	 */
	@RequestMapping(value = "/classes/dp/{dpId}" ,method=RequestMethod.GET)
	public Result GetclassdpId(@PathVariable("dpId") String dpId) {
		System.out.println("查询院系号为========"+dpId+"的所有班级信息");
		return classervice.selectClassByDp(Integer.parseInt(dpId));
	}
	
	/**
	 * 
	 * @Title: DELETEclassbyId
	 * @Description: TODO(删除单个班级)
	 * @param @param classId
	 * @throws
	 */
	@RequestMapping(value = "/classes/{classId}" ,method=RequestMethod.DELETE)
	public Result DELETEclassbyId(@PathVariable("classId") String classId) {
		System.out.println("删除班级号为========"+classId+"的信息");
		return classervice.deleteClassById(Integer.parseInt(classId));
	}
	
	
	/**
	 * 
	 * @Title: PUTClassById
	 * @Description: TODO(修改单个班级信息)
	 * @param @param json
	 * @throws
	 */
	@RequestMapping(value = "/classes" ,method=RequestMethod.PUT)
	public Result PUTClassById(@RequestBody String json) {
		Classes classes = gson.fromJson(json,Classes.class);
		return classervice.updateClassById(classes);
	}
	
	/**
	 * 
	 * @Title: POSTClassById
	 * @Description: TODO(增加单个班级信息)
	 * @param @param json
	 * @throws
	 */
	
	@RequestMapping(value = "/classes" ,method=RequestMethod.POST)
	public Result POSTClassById(@RequestBody String json) {
		Classes classes = gson.fromJson(json,Classes.class);
		return classervice.insertClassById(classes);
	}
	
	
	
}
