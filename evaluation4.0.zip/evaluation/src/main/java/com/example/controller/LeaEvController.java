package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.LeaderEvaluation;
import com.example.result.Result;
import com.example.service.LeaEvService;
import com.google.gson.Gson;

/**
 * @describe 领导评教题目控制层
 * @author 游中成
 * @date 2019年9月25日 上午10:48:54
 */

@RestController
@RequestMapping("/api")
public class LeaEvController {
	
	@Autowired
	private LeaEvService leaEvService;
	
	Gson gson = new Gson();
	
	/**
	 * 
	 * @describe 插入教师评教题目
	 * @param String json
	 * @return Result
	 */
	@RequestMapping(value = "/LeaEv" ,method = RequestMethod.POST)
	public Result insertLeaEv(@RequestBody String json) {
		
		LeaderEvaluation leaderEvaluation = gson.fromJson(json, LeaderEvaluation.class);
//		LeaderEvaluation leaderEvaluation = new LeaderEvaluation();
//		leaderEvaluation.setLeaQuestion("教学工作量");leaderEvaluation.setEsA("超工作量");
//		leaderEvaluation.setEsB("满工作量");leaderEvaluation.setEsC("接近完成（70%）");leaderEvaluation.setEsD("差距较大");
		return leaEvService.insertLeaEv(leaderEvaluation);	
	}
	
	
	/**
	 * 
	 * @describe 删除教师评教题目
	 * @param String leaId
	 * @return Result
	 */
	@RequestMapping(value ="LeaEv/{leaId}",method = RequestMethod.DELETE)
	public Result deleteLeaVe(@PathVariable("leaId") String leaId) {
		return leaEvService.deleteLeaVe(Integer.parseInt(leaId));
		
	}
		
	
	/**
	 * 
	 * @describe 修改教师评教题目
	 * @param String json
	 * @return Result
	 */
	@RequestMapping(value ="LeaEv",method = RequestMethod.PUT)
	public Result updateLeaVe(@RequestBody String json) {
		 LeaderEvaluation leaderEvaluation  = gson.fromJson(json, LeaderEvaluation.class);
		return leaEvService.updateLeaVe(leaderEvaluation);
		
	}
	
	
	
	/**
	 * 
	 * @describe  查询所有题目信息
	 * @param 
	 * @return Result
	 */
	@RequestMapping(value = "LeaEv", method = RequestMethod.GET)
	public Result seletAllLeaVe() {
		return leaEvService.seletAllLeaVe();
	}
	
	/**
	 * 
	 * @describe 根据id查询题目信息
	 * @param String leaId
	 * @return Result
	 */
	@RequestMapping(value = "LeaEv/{leaId}", method = RequestMethod.GET)
	public Result selectLeaEvById(@PathVariable("leaId") String leaId) {
		return leaEvService.selectLeaEvById(Integer.parseInt(leaId));
		
	}
	
	
	

}
