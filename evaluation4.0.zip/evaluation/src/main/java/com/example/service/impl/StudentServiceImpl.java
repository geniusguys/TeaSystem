package com.example.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.StudentDao;
import com.example.domain.Student;
import com.example.result.Result;
import com.example.result.ResultFactory;
import com.example.service.StudentService;
/**
 * @describe 学生类服务层实现类
 * @author genius
 * @Date 2019-9-18 15:06
 */


@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	public StudentDao stuDao;

	
	@Override
	public Result selectStudent() {  //查询全部学生信息
		// TODO Auto-generated method stub
		List<Student> list = stuDao.selectStudent();
		if(list == null) {
			return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
		
	}
	
	@Override
	public Result selectStudentById(int stuId) {//查询单个学生信息
		// TODO Auto-generated method stub
		List<Student> list = stuDao.selectStudentById(stuId);
		if(list == null) {
			return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
	}
	
	



	

	@Override
	public Result updateStudentById(Student student) { //修改学生信息
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //时间
		student.setRecordTime(df.format(new Date()));
		int row  = stuDao.updateStudentById(student);
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}

	

	@Override
	public Result insertStudentById(Student student) { // 增加新学生信息
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //时间
		student.setStuPassword("123456");
		student.setRecordTime(df.format(new Date()));
		
		int row  = stuDao.insertStudentById(student);
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}

	
	@Override
	public Result deleteStudentById(int stuId) {//删除学生信息
		// TODO Auto-generated method stub
		int row  = stuDao.deleteStudentById(stuId);
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}

	



	
	
}
