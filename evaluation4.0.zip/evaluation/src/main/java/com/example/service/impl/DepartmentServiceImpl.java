package com.example.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.DepartmentDao;

import com.example.domain.Department;
import com.example.result.Result;
import com.example.result.ResultFactory;
import com.example.service.DepartmentService;

/**
 * @describe 部门服务层实现类
 * @author 游中成
 * @Date 2019-9-23 10：55
 */
@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	public DepartmentDao depDao;
	
	
	@Override
	public Result selectDepartment() {//查询所有部门信息
		// TODO Auto-generated method stub
		//System.out.println("DepartmentServiceImpl ..........DepartmentController");
		List<Department> list=depDao.selectDepartment();
		if(list.size()<=0) {
			return ResultFactory.buildDefaultFailResult();
			
		}
		return ResultFactory.buildSuccessResult(list);
	}



	@Override
	public Result insertDepartment(Department department) {//添加部门
		// TODO Auto-generated method stub
		//记录时间戳
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		department.setRecordTime(df.format(new Date()));
		int row = depDao.insertDepartment(department);
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}else {
			return ResultFactory.buildDefaultFailResult();
		}
		
	}


	/**
	 * 
	 * @describe 根据部门 ID dpId 删除部门信息
	 * @param teaId
	 * @return
	 */
	@Override
	public Result deleteDepartment(int dpId) {//根据部门ID dpId 删除部门信息
		
		int row = depDao.deleteDepartment(dpId);
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}else {
			return ResultFactory.buildDefaultFailResult();
		}
		
	}

	/**
	 * 
	 * @describe  修改部门信息
	 * @param dpId
	 * @return Result
	 */

	@Override
	public Result updateDepartment(Department department) {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		department.setRecordTime(df.format(new Date()));
		int row = depDao.updateDepartment(department);
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}else {
			return ResultFactory.buildDefaultFailResult();
		}
		
	}

	
	/**
	 * 
	 * @describe  查询部门信息
	 * @param dpId
	 * @return Result
	 */

	@Override
	public Result selectDepartmentById(int dpId) {
		List<Department> list = depDao.selectDepartmentById(dpId);
		if(list.size()>0) {
			return ResultFactory.buildSuccessResult(list);
		}else {
			return ResultFactory.buildDefaultFailResult();
		}
		
	}
}
