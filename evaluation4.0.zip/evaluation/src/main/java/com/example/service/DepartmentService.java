package com.example.service;


import com.example.domain.Department;
import com.example.result.Result;

/**
 * @describe 部门服务层接口
 * @author 游中成
 * @Date 2019-9-23 10：55
 */
public interface DepartmentService {

	public Result selectDepartment();//查询所有部门信息

	public Result insertDepartment(Department department);//添加部门

	public Result deleteDepartment(int  dpId);//根据部门 ID dpId 删除部门信息

	public Result updateDepartment(Department department);// 修改部门信息

	public Result selectDepartmentById(int dpId);//根据部门 ID dpId 查询删除部门信息
}
