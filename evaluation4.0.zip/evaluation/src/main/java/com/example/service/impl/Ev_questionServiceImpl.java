package com.example.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.Ev_questionDao;
import com.example.domain.Ev_question;
import com.example.result.Result;
import com.example.result.ResultFactory;
import com.example.service.Ev_questionService;


/**
 * 
 * @ClassName: Ev_questionServiceImpl
 * @Description: TODO service实现层
 * @author 郭海滨
 * @date 2019年9月25日
 *
 */
@Service
public class Ev_questionServiceImpl implements Ev_questionService {

	@Autowired
	public Ev_questionDao  ev_qdao;
	
	@Override
	public Result selectEv_q() {//查询所有题目
		// TODO Auto-generated method stub
		List<Ev_question> list = ev_qdao.selectEv_q();
		if(list == null) {
			return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
		
	}

	@Override
	public Result selectEv_qById(int eqId) {//通过Id查询单个题目
		// TODO Auto-generated method stub
		List<Ev_question> list = ev_qdao.selectEv_qById(eqId);
		if(list == null) {
			return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
	}

	@Override
	public Result selectEv_qByTp(int dpId) {//通过类型查多个题目
		// TODO Auto-generated method stub
		List<Ev_question> list = ev_qdao.selectEv_qByTp(dpId);
		if(list == null) {
			return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
	}
	
	@Override  
	public Result select_all() {//查询题目和选项      全部
		// TODO Auto-generated method stub
		List<Ev_question> list = ev_qdao.select_all();
		if(list == null) {
			return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
	}

	@Override
	public Result select_allById(int eqId) {//查询题目和选项    单个
		// TODO Auto-generated method stub
		List<Ev_question> list = ev_qdao.select_allById(eqId);
		if(list == null) {
			return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
	}
	
	
	@Override
	public Result select_order(String eqType) { //查询   随机个  题目和选项
		// TODO Auto-generated method stub
		List<Ev_question> list = ev_qdao.select_order(eqType);
		if(list == null) {
			return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
	}

	
	/*
	 * @Override public Result select_all(int eqId) {//查询题目和选项 // TODO
	 * Auto-generated method stub List<Ev_question> list = ev_qdao.select_all(eqId);
	 * if(list == null) { return ResultFactory.buildDefaultFailResult(); } return
	 * ResultFactory.buildSuccessResult(list); }
	 */
	

	@Override
	public Result updateEv_qById(Ev_question ev_question) {//修改单个题目
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //时间
		ev_question.setRecordTime(df.format(new Date()));
		int row = ev_qdao.updateEv_qById(ev_question);
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}

	@Override
	public Result insertEv_q(Ev_question ev_question) {//插入单个题目
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //时间
		ev_question.setRecordTime(df.format(new Date()));
		int row = ev_qdao.insertEv_q(ev_question);
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}

	@Override
	public Result deleteEv_qById(int eqId) {//删除单个题目
		// TODO Auto-generated method stub
		int row = ev_qdao.deleteEv_qById(eqId);
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}




	

}
