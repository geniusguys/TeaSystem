package com.example.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.ClassesDao;
import com.example.domain.Classes;
import com.example.result.Result;
import com.example.result.ResultFactory;
import com.example.service.ClassesService;

@Service
public class ClassesServiceImpl implements ClassesService {

	@Autowired
	public ClassesDao clsdao;
	
	@Override
	public Result selectClass() {  //查询所有班级
		// TODO Auto-generated method stub
		List<Classes> list = clsdao.selectClass();
		if(list == null) {
			return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
	}

	@Override
	public Result selectClassById(int classId) {//查询单个班级
		// TODO Auto-generated method stub
		List<Classes> list = clsdao.selectClassById(classId);
		if(list == null) {
			return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
	}
	
	@Override
	public Result selectClassByDp(int dpId) {//查询同院系班级
		// TODO Auto-generated method stub
		List<Classes> list = clsdao.selectClassByDp(dpId);
		System.out.println("查询结果---------------------------------------------------------");
		System.out.println(list);
		if(list == null) {
			return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
		
	}
	
	@Override
	public Result deleteClassById(int classId) {//删除单个班级
		// TODO Auto-generated method stub
		int row  =  clsdao.deleteClassById(classId);
		
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}

	@Override
	public Result updateClassById(Classes classes) {//修改单个班级
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //时间
		classes.setRecordTime(df.format(new Date()));
		int row  =  clsdao.updateClassById(classes);
		
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}
	

	@Override
	public Result insertClassById(Classes classes) {//插入单个班级
		// TODO Auto-generated method stub
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //时间
		classes.setRecordTime(df.format(new Date()));
		int row  =  clsdao.insertClassById(classes);
		
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}

}
