package com.example.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.LeaEvDao;
import com.example.domain.LeaderEvaluation;
import com.example.result.Result;
import com.example.result.ResultFactory;
import com.example.service.LeaEvService;
/**
 * describe 领导评教实现层
 * @author 游中成
 * @date 2019年9月25日 上午10:54:27
 */
@Service
public class LeaEvServiceImpl implements LeaEvService {
	
	@Autowired
	private LeaEvDao leaEvDao;
	
	

	/**
	 * 
	 * @describe 插入教师评教题目
	 * @param String json
	 * @return Result
	 */
	@Override
	public Result insertLeaEv(LeaderEvaluation leaderEvaluation) { //插入教师评教题目
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		leaderEvaluation.setRecordTime(df.format(new Date()));
		int row = leaEvDao.insertLeaEv(leaderEvaluation);
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}else {
			return ResultFactory.buildDefaultFailResult();
		}
		
	}


	/**
	 * 
	 * @describe 删除教师评教题目
	 * @param String leaId
	 * @return Result
	 */
	@Override
	public Result deleteLeaVe(int leaId) {
		int row = leaEvDao.deleteLeaVe(leaId);
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}else {
			return ResultFactory.buildDefaultFailResult();
		}
	}

	/**
	 * 
	 * @describe 修改教师评教题目
	 * @param LeaderEvaluation leaderEvaluation
	 * @return Result
	 */
	@Override
	public Result updateLeaVe(LeaderEvaluation leaderEvaluation) {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		leaderEvaluation.setRecordTime(df.format(new Date()));
	    int row = leaEvDao.updateLeaVe(leaderEvaluation);
	    if(row>0) {
	    	return ResultFactory.buildDefaultSuccessResult();
	    }else {
	    	return ResultFactory.buildDefaultFailResult();
	    }
	}


	/**
	 * 
	 * @describe  查询所有题目信息
	 * @param 
	 * @return Result
	 */
	@Override
	public Result seletAllLeaVe() {
		List<LeaderEvaluation> list=  leaEvDao.seletAllLeaVe();
		if(list.size()>0) {
			return ResultFactory.buildSuccessResult(list);
		}else {
			return ResultFactory.buildDefaultFailResult();
		}
	}

	/**
	 * 
	 * @describe  根据id查询题目信息
	 * @param leaId
	 * @return Result
	 */
	@Override
	public Result selectLeaEvById(int leaId) {
		List<LeaderEvaluation> list=  leaEvDao.selectLeaEvById(leaId);
		if(list.size()>0) {
			return ResultFactory.buildSuccessResult(list);
		}else {
			return ResultFactory.buildDefaultFailResult();
		}
	}

}
