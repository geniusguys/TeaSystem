package com.example.service;

import com.example.domain.Student;
import com.example.result.Result;

/**
 * @describe 学生类服务层接口
 * @author genius
 * @Date 2019-9-18 15:01
 */
public interface StudentService {
	
	public Result selectStudent();//查询所有学生
	
	public Result selectStudentById(int stuId);//根据id查询单个学生
	
	public Result updateStudentById(Student student);//修改学生信息
	
	public Result insertStudentById(Student student);//添加学生信息

	public Result deleteStudentById(int stuId);//删除学生信息
}
