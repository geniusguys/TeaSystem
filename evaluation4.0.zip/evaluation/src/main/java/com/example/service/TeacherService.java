package com.example.service;

import com.example.domain.Teacher;
import com.example.result.Result;

/**
 * @describe 教师类服务层接口类
 * @author 游中成
 * @date 2019年9月23日  下午3:35:00
 */
public interface TeacherService {
	

	public Result selectTeacher();//查询所有教师信息

	public Result insertTeacher(Teacher teacher);//添加教师信息

	public Result delTeacher(int teaId);//根据教师id删除教师信息

	public Result selectTeacherById(String teaId);//根据教师id teaId 查询教师信息

	public Result updateTeaInfoById(Teacher teacher); //根据教师id teaId 修改教师信息
	
	
	
}
