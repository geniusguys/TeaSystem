package com.example.service;

import com.example.domain.Classes;
import com.example.result.Result;

/**
 * 
 * @ClassName: ClassesService
 * @Description: TODO
 * @author 郭海滨
 * @date 2019年9月24日
 *
 */
public interface ClassesService {
	
	public Result selectClass();//查询所有班级
	public Result selectClassById(int classId);//查询单个班级
	public Result selectClassByDp(int dpId);//查询相同院系的班级
	
	public Result deleteClassById(int classId);// 删除单个班级
	
	public Result  updateClassById(Classes classes);// 修改单个班级
	public Result  insertClassById(Classes classes);// 插入单个班级
}
