package com.example.service;


import com.example.domain.AssigningCourse;
import com.example.domain.Course;
import com.example.domain.Term;
import com.example.result.Result;

/**
 * @describe 公共接口
 * @author genius
 * @Date 2019-9-22 20:27
 */
public interface CommonService{

	//=======================TERM(学期)=======================================
	
	Result insertTerm(Term term);//添加学期信息到数据库

	Result queryAllTerm();//查询全部的学期信息

	Result delTerm(int parseInt);//根据学期ID删除学期信息

	Result updateTerm(Term term);//根据学期ID修改学期信息

	Result lookTermInfoById(int parseInt);//根据学期ID查看学期信息
	
	//========================COURSE(课程)=======================================
	
	Result insertCourse(Course course);//插入课程信息

	Result queryAllCourse();//查询全部课程信息

	Result lookCourseInfoById(int courseId);//根据课程ID查看学期信息

	Result delCourse(int courseId);//根据课程ID删除课程信息

	Result updateCourse(Course course);//根据课程ID修改课程信息

	
	//========================APPORTION(分配管理)=============================================
	
	Result studentApportionClass(int studentId, int classId);//根据学生ID和班级ID分配学生到班级

	Result studentApportionDepartment(int studentId, int dpId);//根据学生ID和院系ID分配学生到院系

	Result classApportionDepartment(int classId, int dpId);//根据班级ID和院系ID分配学生到院系

	Result teacherApportionDepartment(int teacherId, int dpId);//根据教师ID和院系ID分配教师到院系

	Result apportionAssigningCourse(AssigningCourse assigningCourse);//分配授课表信息

	Result apportionQuestionSelect(int eqId, int esId);//分配评教题目选项信息
	

	

	
}
