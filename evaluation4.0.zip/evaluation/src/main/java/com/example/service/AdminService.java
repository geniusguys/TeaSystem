package com.example.service;

import com.example.domain.Admin;
import com.example.result.Result;

/**
 * @describe 管理员服务层接口
 * @author genius
 * @Date 2019-9-18 15:00
 */
public interface AdminService {

	//public Result selectAdminById(Integer adminId);// 根据管理员ID查询管理员信息

	public Result selectAdmin();//查询所有管理员

	public Result insertAdmin(Admin admin);//添加管理员

	public Result lookAdmin(int id);//根据ID查看管理员

	public Result delAdmin(int id);//根据管理员ID删除管理员

	public Result updateAdmin(Admin admin);//修改管理员信息
}
