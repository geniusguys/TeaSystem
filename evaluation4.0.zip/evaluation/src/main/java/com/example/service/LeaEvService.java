package com.example.service;


import com.example.domain.LeaderEvaluation;
import com.example.result.Result;

/**
 * @describe 领导评教层接口
 * @author 游中成
 * @date 2019年9月25日 上午10:52:08
 */

public interface LeaEvService {

	public  Result insertLeaEv(LeaderEvaluation leaderEvaluation);//插入教师评教题目

	public Result deleteLeaVe(int leaId);//删除教师评教题目

	public Result updateLeaVe(LeaderEvaluation leaderEvaluation);//修改教师评教题目

	public Result seletAllLeaVe();// 查询所有题目信息

	public Result selectLeaEvById(int leaId);//根据id查询题目信息

}
