package com.example.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.TeacherDao;
import com.example.domain.Teacher;
import com.example.result.Result;
import com.example.result.ResultFactory;
import com.example.service.TeacherService;
/**
 * @describe 教师类服务层实现类
 * @author genius
 * @Date 2019-9-18 15:06
 */
@Service
public class TeacherServiceImpl implements TeacherService{

	@Autowired
	public TeacherDao teacherDao;
	
	
	/**
	 * @ TODO 查询所有教师信息
	 * @param teaId
	 * @return
	 */
	@Override
	public Result selectTeacher() {
		// TODO Auto-generated method stub
		//System.out.println("TeacherDao.................selectTeacher");
		List<Teacher> list = teacherDao.selectTeacher();
		if(list.size()<=0) {
			return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
	}


	/**
	 * @ TODO 添加教师信息
	 * @param teaId
	 * @return
	 */
	@Override
	public Result insertTeacher(Teacher teacher) {
		//记录时间戳
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		teacher.setTeaPassword("123456");
		teacher.setRecordTime(df.format(new Date()));
		
		System.out.println(teacher.getRecordTime());
		int row = teacherDao.insertTeacher(teacher);
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}else {
			return ResultFactory.buildDefaultFailResult();
		}
		
	}


	/**
	 * 
	 * @ TODO 根据教师ID删除教师信息
	 * @param teaId
	 * @return
	 */
	@Override
	public Result delTeacher(int teaId) {
		// TODO Auto-generated method stub
		int row = teacherDao.delTeacher(teaId);
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}else {
			return ResultFactory.buildDefaultFailResult();
		}
		
	}


	/**
	 * @ TODO 根据教师ID teaId 查询 教师信息
	 * @param teaId
	 * @return
	 */
	@Override
	public Result selectTeacherById(String teaId) {
		// TODO Auto-generated method stub
		List<Teacher>  list = teacherDao.selectTeacherById(teaId);
		if(list.size()>0) {
			return ResultFactory.buildSuccessResult(list);
		}else {
			return ResultFactory.buildDefaultFailResult();
		}
		
	}
	

	/**
	 * @describe 根据教师id teaId 修改教师信息
	 * @param String teaId
	 * @return Result
	 */
	
	@Override
	public Result updateTeaInfoById(Teacher teacher) {
		// TODO Auto-generated method stub
		//记录时间戳
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		teacher.setRecordTime(df.format(new Date()));
	
		int row = teacherDao.updateTeaInfoById(teacher);
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}else {
			return ResultFactory.buildDefaultFailResult();
		}
		
	}




}
