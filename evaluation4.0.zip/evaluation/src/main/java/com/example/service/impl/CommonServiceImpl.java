package com.example.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.CommonDao;
import com.example.domain.AssigningCourse;
import com.example.domain.Course;
import com.example.domain.Term;
import com.example.result.Result;
import com.example.result.ResultFactory;
import com.example.service.CommonService;
/**
 * @describe 公共类服务层实现类
 * @author genius
 * @Date 2019-9-22 20:28
 */
@Service
public class CommonServiceImpl implements CommonService {

	@Autowired
	public CommonDao commonDao;

	//=====================TERM(学期)===============================================
	
	@Override
	public Result insertTerm(Term term) {//添加学期信息到数据库
		//记录时间戳
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		term.setRecordTime(df.format(new Date()));
		
		int row_insert=commonDao.insertTerm(term);
		
		if(row_insert>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}

	@Override
	public Result queryAllTerm() {//查询全部的学期信息
		
		List<Term> list=commonDao.queryAllTerm();
		
		if(list==null) {
			return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
	}

	@Override
	public Result delTerm(int termId) {//根据学期ID删除学期信息
		
		int row_del=commonDao.delTerm(termId);
		
		if(row_del>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultSuccessResult();
	}

	@Override
	public Result updateTerm(Term term) {//根据学期ID修改学期信息
		//记录时间戳
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		term.setRecordTime(df.format(new Date()));
		
		int row_update=commonDao.updateTerm(term);
		
		if(row_update>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}

	@Override
	public Result lookTermInfoById(int termId) {//根据学期ID查看学期信息
		
		List<Term> list=commonDao.lookTermInfoById(termId);
		
		if(list==null) {
			return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
	}
	
	//=========================COURSE(课程)==================================================
	
	@Override
	public Result insertCourse(Course course) {//插入课程信息
		//记录时间戳
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		course.setRecordTime(df.format(new Date()));
		
		int row_insert=commonDao.insertCourse(course);
		if(row_insert>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}

	@Override
	public Result queryAllCourse() {//查询全部课程信息
		
		List<Course> list=commonDao.queryAllCourse();
		
		if(list==null) {
			return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
	}

	@Override
	public Result lookCourseInfoById(int courseId) {//根据课程ID查看课程信息
		
		List<Course> list=commonDao.lookCourseInfoById(courseId);
		
		 if(list==null) {
				return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
	}

	@Override
	public Result delCourse(int courseId) {//根据课程ID删除课程信息
		
		int row_del=commonDao.delCourse(courseId);
		
		if(row_del>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultSuccessResult();
	}

	@Override
	public Result updateCourse(Course course) {//根据课程ID修改课程信息
		//记录时间戳
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		course.setRecordTime(df.format(new Date()));
		
		int row_update=commonDao.updateCourse(course);
		
		if(row_update>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}

	//===========================APPORTION(分配管理)=============================================
	
	@Override
	public Result studentApportionClass(int studentId, int classId) {//根据学生ID和班级ID分配学生到班级
		
		int stuToClass=commonDao.studentApportionClass(studentId,classId);
		
		if(stuToClass>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}

	@Override
	public Result studentApportionDepartment(int studentId, int dpId) {//根据学生ID和院系ID分配学生到院系
		
		int stuToDepartment=commonDao.studentApportionDepartment(studentId,dpId);
		
		if(stuToDepartment>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}

	@Override
	public Result classApportionDepartment(int classId, int dpId) {//根据班级ID和院系ID分配学生到院系
		
		int classToDepartment=commonDao.classApportionDepartment(classId,dpId);
		
		if(classToDepartment>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}

	@Override
	public Result teacherApportionDepartment(int teacherId, int dpId) {//根据教师ID和院系ID分配教师到院系
		
		int teacherToDepartment=commonDao.teacherApportionDepartment(teacherId,dpId);
		
		if(teacherToDepartment>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}

	@Override
	public Result apportionAssigningCourse(AssigningCourse assigningCourse) {//分配授课表信息
		//记录时间戳
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		assigningCourse.setRecordTime(df.format(new Date()));
		
		int insertAssigningCourse=commonDao.apportionAssigningCourse(assigningCourse);
		
		if(insertAssigningCourse>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}

	@Override
	public Result apportionQuestionSelect(int eqId, int esId) {//分配评教题目选项信息
		
		int qsrow=commonDao.apportionQuestionSelect(eqId,esId);
		
		if(qsrow>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}


}
