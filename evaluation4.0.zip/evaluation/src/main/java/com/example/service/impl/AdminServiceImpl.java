package com.example.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.AdminDao;
import com.example.domain.Admin;
import com.example.result.Result;
import com.example.result.ResultFactory;
import com.example.service.AdminService;


/**
 * @describe 管理员类服务层实现类
 * @author genius
 * @Date 2019-9-18 15:06
 */
@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
	public AdminDao adminDao;
	
//	@Override
//	public Result selectAdminById(Integer adminId) {//根据管理员ID查询管理员信息
//		
//		return adminDao.selectAdminById(adminId);
//	}

//	@Override
//	public List<Admin> selectAdmin() {//查询所有管理员
//		
//		List<Admin> list=adminDao.selectAdmin();
//		return list;
//	}
	
	@Override
	public Result selectAdmin() {//查询所有管理员
		
		List<Admin> list=adminDao.selectAdmin();
		if(list == null) {
			return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
	}
	

	@Override
	public Result insertAdmin(Admin admin) {//添加管理员
		//记录时间戳
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		admin.setAdminPassword("123456");
		admin.setRecordTime(df.format(new Date()));
		
		int row=adminDao.insertAdmin(admin);
		if(row>0) {
			
			Admin adminLast=adminDao.lastRecord();//查询最新插入的一条记录
			
			return ResultFactory.buildSuccessResult(adminLast);
		}
		return ResultFactory.buildDefaultFailResult();
	}
	
	@Override
	public Result lookAdmin(int adminId) {//根据管理员ID查看管理员
		List<Admin> list=adminDao.lookAdmin(adminId);
		if(list==null) {
			return ResultFactory.buildDefaultFailResult();
		}
		return ResultFactory.buildSuccessResult(list);
	}

	@Override
	public Result delAdmin(int id) {//根据管理员ID删除管理员
		int row=adminDao.delAdmin(id);
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}

	@Override
	public Result updateAdmin(Admin admin) {//修改管理员信息
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		admin.setRecordTime(df.format(new Date()));
		int row=adminDao.updateAdmin(admin);
		
		if(row>0) {
			return ResultFactory.buildDefaultSuccessResult();
		}
		return ResultFactory.buildDefaultFailResult();
	}



}
