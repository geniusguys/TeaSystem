package com.example.service;


import com.example.domain.Ev_question;
import com.example.result.Result;
/**
 * 
 * @ClassName: Ev_questionService
 * @Description: TODO service
 * @author 郭海滨
 * @date 2019年9月25日
 *
 */
public interface Ev_questionService {

	
	public Result selectEv_q();//查询所有班级
	public Result selectEv_qById(int eqId);//查询单个班级
	public Result selectEv_qByTp(int dpId);//查询相同院系的班级
	
	
	public Result select_all();//联表查询全部题目
	public Result select_allById(int eqId);//连表查询单个题目
	public Result select_order(String eqType);//根据类型随机查询n个题目
	
	public Result updateEv_qById(Ev_question ev_question);// 修改单个班级
	
	
	public Result insertEv_q(Ev_question ev_question);// 插入单个班级
	
	public Result deleteEv_qById(int eqId);// 删除单个班级
}
