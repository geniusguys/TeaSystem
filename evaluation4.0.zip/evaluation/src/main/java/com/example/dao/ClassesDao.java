package com.example.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.domain.Classes;

/**
 * 
 * @ClassName: ClassesDao
 * @Description: classesdao层接口
 * @author 郭海滨
 * @date 2019年9月24日
 *
 */
@Repository
public interface ClassesDao  {
	
	public List<Classes> selectClass();//查询所有班级
	public List<Classes> selectClassById(int classId);//查询单个班级
	public List<Classes> selectClassByDp(int dpId);//查询相同院系的班级
	
	public int deleteClassById(int classId);// 删除单个班级
	
	public int  updateClassById(Classes classes);// 修改单个班级
	public int  insertClassById(Classes classes);// 插入单个班级
	
	

	
}
