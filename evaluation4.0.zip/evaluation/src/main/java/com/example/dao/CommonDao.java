package com.example.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.domain.AssigningCourse;
import com.example.domain.Course;
import com.example.domain.Term;

/**
 * @describe 公共DAO层接口
 * @author genius 
 * @Date 2019-9-22 20:30
 */
@Repository
public interface CommonDao {

	int insertTerm(Term term);//添加学期信息到数据库

	List<Term> queryAllTerm();//查询全部的学期信息

	int delTerm(int termId);//根据学期ID删除学期信息

	int updateTerm(Term term);//根据学期ID修改学期信息

	List<Term> lookTermInfoById(int termId);//根据学期ID查看学期信息
	
	//====================================================================
	
	int insertCourse(Course course);//插入课程信息

	List<Course> queryAllCourse();//查询全部课程信息

	List<Course> lookCourseInfoById(int courId);//根据课程ID查看课程信息

	int delCourse(int courId);//根据课程ID删除课程信息

	int updateCourse(Course course);//根据课程ID修改课程信息
	
	//=======================================================================

	int studentApportionClass(int stuId, int classId);//根据学生ID和班级ID分配学生到班级

	int studentApportionDepartment(int stuId, int dpId);//根据学生ID和院系ID分配学生到院系

	int classApportionDepartment(int classId, int dpId);//根据班级ID和院系ID分配学生到院系

	int teacherApportionDepartment(int teaId, int dpId);//根据教师ID和院系ID分配教师到院系

	int apportionAssigningCourse(AssigningCourse assigningCourse);//分配授课表信息

	int apportionQuestionSelect(int eqId, int esId);//分配评教题目选项信息

	

	
}
