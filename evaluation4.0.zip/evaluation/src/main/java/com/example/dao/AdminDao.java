package com.example.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.domain.Admin;
/**
 * @describe 管理员DAO层接口
 * @author genius 
 * @Date 2019-9-18 11:12
 */
@Repository
public interface AdminDao {

	public Admin selectAdminById(int AdminId); //根据管理员ID查询管理员信息

	public List<Admin> selectAdmin();//查询所有管理员

	public int insertAdmin(Admin admin);//添加管理员

	public List<Admin> lookAdmin(int adminId);//查看管理员

	public int delAdmin(int adminId);//根据管理员ID删除管理员

	public int updateAdmin(Admin admin);////修改管理员信息

	public Admin lastRecord();//查询最新插入的一条记录
}
