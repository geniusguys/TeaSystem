package com.example.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.domain.Ev_question;


/**
 * 
 * @ClassName:Ev_questionDao
 * @Description: TODO(学生教师评价题库dao层接口)
 * @author 郭海滨
 * @date 2019年9月25日
 *
 */
@Repository
public interface Ev_questionDao {

	public List<Ev_question> selectEv_q();//查询所有班级
	
	public List<Ev_question> select_all();//连表查询多个题目
	public List<Ev_question> select_order(String eqType);//根据类型随机查询n个题目
	public List<Ev_question> selectEv_qById(int eqId);//查询单个班级
	public List<Ev_question> selectEv_qByTp(int dpId);//查询相同院系的班级
	
	public List<Ev_question> select_allById(int eqId);//联表查询单个题目
	
	public int  updateEv_qById(Ev_question ev_question);// 修改单个班级
	public int  insertEv_q(Ev_question ev_question);// 插入单个班级
	
	public int deleteEv_qById(int eqId);// 删除单个班级
}
