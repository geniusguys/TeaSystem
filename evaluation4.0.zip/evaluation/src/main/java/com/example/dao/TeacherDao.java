package com.example.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.domain.Teacher;

/**
 * 
 * @author 游中成
 * @date 2019年9月23日 下午3:46:24
 */
@Repository
public interface TeacherDao {


	public List<Teacher> selectTeacher();//查询教师信息

	public int insertTeacher(Teacher teacher);//添加教师信息

	public int delTeacher(int teaId);//根据教师ID删除教师信息

	public List<Teacher> selectTeacherById(String teaId);// 根据教师ID teaId 查询 教师信息

	public int updateTeaInfoById(Teacher teacher);//根据教师id teaId 修改教师信息
	
}
