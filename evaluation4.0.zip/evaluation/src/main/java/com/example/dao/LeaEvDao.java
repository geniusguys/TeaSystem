package com.example.dao;

import java.util.List;

import com.example.domain.LeaderEvaluation;
/***
 * @describe 领导DAO层接口
 * @author 游中成
 * @date 2019年9月25日 上午11:05:03
 */
public interface LeaEvDao {

	public int insertLeaEv(LeaderEvaluation leaderEvaluation); //插入教师评教题目

	public int deleteLeaVe(int leaId);//删除教师评教题目

	public int updateLeaVe(LeaderEvaluation leaderEvaluation);// 修改教师评教题目

	public List<LeaderEvaluation> seletAllLeaVe();// 查询所有题目信息

	public List<LeaderEvaluation> selectLeaEvById(int leaId);//根据id查询题目信息

}
