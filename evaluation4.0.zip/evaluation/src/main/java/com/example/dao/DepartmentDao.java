package com.example.dao;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.example.domain.Department;
/**
 * @describe 部门DAO层接口
 * @author 游中成
 * @Date 2019-9-23 11:11
 */
@Repository
public interface DepartmentDao {

	public List<Department> selectDepartment() ;//查询所有部门信息

	public int insertDepartment(Department department);//添加部门

	public int deleteDepartment(int dpId);//根据部门 ID dpId 删除部门信息

	public int updateDepartment(Department department);//修改部门信息

	public List<Department> selectDepartmentById(int dpId);//根据部门id 查询部门信息
	

}
