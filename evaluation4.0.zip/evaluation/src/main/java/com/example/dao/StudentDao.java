package com.example.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.domain.Student;

/**
 * @describe 学生DAO层接口
 * @author 郭海滨
 * @Date 2019-9-18 12:12
 */
@Repository
public interface StudentDao {
	
	public List<Student> selectStudentById(int stuId);// 通过Id来查询单个学生

	public List<Student> selectStudent();// 查询所有学生
	
	public int updateStudentById(Student student);//修改学生信息

	public int insertStudentById(Student student);// 添加学生信息

	public int deleteStudentById(int stuId);// 删除学生信息
}
