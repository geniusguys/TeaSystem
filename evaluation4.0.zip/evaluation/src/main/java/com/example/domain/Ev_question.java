package com.example.domain;

import java.util.List;

/**
 * 
 * @ClassName: ev_question
 * @Description: 学生-教师  教师-教师题库实体类
 * @author 郭海滨
 * @date 2019年9月25日
 *
 */
public class Ev_question {
	private Integer eqId;//题目Id
	private Integer esId;//选项Id
	private String eqType;//评价者
	private String evaQuestion;//题目
	private String comment;//备注
	private String recordTime;//创建时间
	private List<Ev_select>  ev_select ;
	
	
	
	
	

	public List<Ev_select> getEv_select() {
		return ev_select;
	}
	public void setEv_select(List<Ev_select> ev_select) {
		this.ev_select = ev_select;
	}
	public Integer getEqId() {
		return eqId;
	}
	public void setEqId(Integer eqId) {
		this.eqId = eqId;
	}
	public Integer getEsId() {
		return esId;
	}
	public void setEsId(Integer esId) {
		this.esId = esId;
	}
	public String getEqType() {
		return eqType;
	}
	public void setEqType(String eqType) {
		this.eqType = eqType;
	}
	public String getEvaQuestion() {
		return evaQuestion;
	}
	public void setEvaQuestion(String evaQuestion) {
		this.evaQuestion = evaQuestion;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getRecordTime() {
		return recordTime;
	}
	public void setRecordTime(String recordTime) {
		this.recordTime = recordTime;
	}
	@Override
	public String toString() {
		return "Ev_question [eqId=" + eqId + ", esId=" + esId + ", eqType=" + eqType + ", evaQuestion=" + evaQuestion
				+ ", comment=" + comment + ", recordTime=" + recordTime + ", ev_select=" + ev_select + "]";
	}
	

	
	
}
