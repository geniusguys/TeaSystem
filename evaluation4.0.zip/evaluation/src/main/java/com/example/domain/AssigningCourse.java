package com.example.domain;

/**
 * 
 * @author genius
 * @Date 2019-9-25 22:10
 * @describe 授课实体类
 */
public class AssigningCourse {
	
	private Integer acId;//授课ID
	private Integer termId;//学期ID
	private Integer classId;//班级ID
	private Integer courId;//课程ID
	private Integer teacherId;//教师ID
	private String comment;//授课信息备注
	private String recordTime;//记录时间
	
	
	
	public AssigningCourse() {
		//默认无参构造方法
	}
	public Integer getAcId() {
		return acId;
	}
	public void setAcId(Integer acId) {
		this.acId = acId;
	}
	public Integer getTermId() {
		return termId;
	}
	public void setTermId(Integer termId) {
		this.termId = termId;
	}
	public Integer getClassId() {
		return classId;
	}
	public void setClassId(Integer classId) {
		this.classId = classId;
	}
	public Integer getCourId() {
		return courId;
	}
	public void setCourId(Integer courId) {
		this.courId = courId;
	}
	public Integer getTeacherId() {
		return teacherId;
	}
	public void setTeacherId(Integer teacherId) {
		this.teacherId = teacherId;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getRecordTime() {
		return recordTime;
	}
	public void setRecordTime(String recordTime) {
		this.recordTime = recordTime;
	}
	@Override
	public String toString() {
		return "AssigningCourse [acId=" + acId + ", termId=" + termId + ", classId=" + classId + ", courId=" + courId
				+ ", teacherId=" + teacherId + ", comment=" + comment + ", recordTime=" + recordTime + "]";
	}
	
	
}
