package com.example.domain;


/**
 * 
 * @author genius
 * @Date 2019-9-18 11:24
 * @describe 管理员实体类
 */
public class Admin {

	private Integer adminId;//管理员ID
	private String adminJobNumber;//管理员工号
	private String adminPassword;//管理员密码
	private String adminName;//管理员姓名
	private String adminSex;//管理员性别
	private String comment;//管理员信息备注
	private String recordTime;//记录时间
	
	
	public Admin() {
		//默认无参构造方法
	}
	public Integer getAdminId() {
		return adminId;
	}
	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}

	public String getAdminJobNumber() {
		return adminJobNumber;
	}
	public void setAdminJobNumber(String adminJobNumber) {
		this.adminJobNumber = adminJobNumber;
	}
	public String getAdminPassword() {
		return adminPassword;
	}
	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}

	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getAdminSex() {
		return adminSex;
	}
	public void setAdminSex(String adminSex) {
		this.adminSex = adminSex;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	public String getRecordTime() {
		return recordTime;
	}
	public void setRecordTime(String recordTime) {
		this.recordTime = recordTime;
	}
	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", adminJobNumber=" + adminJobNumber + ", adminPassword=" + adminPassword
				+ ", adminName=" + adminName + ", adminSex=" + adminSex + ", comment=" + comment + ", recordTime="
				+ recordTime + "]";
	}

	

	
	
	
}
