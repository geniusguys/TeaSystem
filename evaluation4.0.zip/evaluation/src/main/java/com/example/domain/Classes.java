package com.example.domain;

/**
 * 
 * @author 郭海滨
 * 班级实体类
 * 2019/9/23
 */
public class Classes {
	private Integer classId;//班级ID
	private Integer dpId;//院系id
	private String className;//班级名称
	private String classType;//班级类型
	private String comment;//备注
	private String recordTime;//创建时间
	public Integer getClassId() {
		return classId;
	}
	public void setClassId(Integer classId) {
		this.classId = classId;
	}
	
	public Integer getDpId() {
		return dpId;
	}
	public void setDpId(Integer dpId) {
		this.dpId = dpId;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getClassType() {
		return classType;
	}
	public void setClassType(String classType) {
		this.classType = classType;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getRecordTime() {
		return recordTime;
	}
	public void setRecordTime(String recordTime) {
		this.recordTime = recordTime;
	}
	@Override
	public String toString() {
		return "classes [classId=" + classId + ", dpId=" + dpId + ", className=" + className + ", classType="
				+ classType + ", comment=" + comment + ", recordTime=" + recordTime + "]";
	}
	
	
	
}
