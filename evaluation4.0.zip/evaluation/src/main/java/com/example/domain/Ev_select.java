package com.example.domain;

/**
 * 
 * @ClassName: ev_select
 * @Description: TODO(学生,老师题库选项表)
 * @author 郭海滨
 * @date 2019年9月25日
 *
 */
public class Ev_select {
	private Integer esId;//题目Id
	private String esA;//评价者
	private String esB;//评价者
	private String esC;//题目
	private String esD;//题目
	private String comment;//备注
	private String recordTime;//创建时间
	public Integer getEsId() {
		return esId;
	}
	public void setEsId(Integer esId) {
		this.esId = esId;
	}
	public String getEsA() {
		return esA;
	}
	public void setEsA(String esA) {
		this.esA = esA;
	}
	public String getEsB() {
		return esB;
	}
	public void setEsB(String esB) {
		this.esB = esB;
	}
	public String getEsC() {
		return esC;
	}
	public void setEsC(String esC) {
		this.esC = esC;
	}
	public String getEsD() {
		return esD;
	}
	public void setEsD(String esD) {
		this.esD = esD;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getRecordTime() {
		return recordTime;
	}
	public void setRecordTime(String recordTime) {
		this.recordTime = recordTime;
	}
	@Override
	public String toString() {
		return "ev_select [esId=" + esId + ", esA=" + esA + ", esB=" + esB + ", esC=" + esC + ", esD=" + esD
				+ ", comment=" + comment + ", recordTime=" + recordTime + "]";
	}
	
	
}
