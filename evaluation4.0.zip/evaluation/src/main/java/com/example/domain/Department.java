package com.example.domain;

/**
 * @describe 部门院系实体类
 * @author genius
 * @Date 2019-9-18 11:50
 * 
 */
public class Department {

	private Integer dpId;//院系ID
	private String dpName;//院系名称
	private String comment;//院系备注
	private String recordTime;//记录时间
	
	public Department() {
		//默认无参构造方法
	}
	public Integer getDpId() {
		return dpId;
	}
	public void setDpId(Integer dpId) {
		this.dpId = dpId;
	}
	public String getDpName() {
		return dpName;
	}
	public void setDpName(String dpName) {
		this.dpName = dpName;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getRecordTime() {
		return recordTime;
	}
	public void setRecordTime(String recordTime) {
		this.recordTime = recordTime;
	}
	@Override
	public String toString() {
		return "Department [dpId=" + dpId + ", dpName=" + dpName + ", comment=" + comment + ", createTime="
				+ ", recordTime=" + recordTime + "]";
	}

	
	
}
