package com.example.domain;

/**
 * @describe 学期实体类
 * @author genius
 * @date 2019-9-22 20:01
 */
public class Term {

	private Integer termId;//学期ID
	private String termName;//学期名称
	private String comment;//信息备注
	private String recordTime;//记录时间
	
	public Term() {
		//系统默认无参构造
	}
	public Integer getTermId() {
		return termId;
	}
	public void setTermId(Integer termId) {
		this.termId = termId;
	}
	public String getTermName() {
		return termName;
	}
	public void setTermName(String termName) {
		this.termName = termName;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getRecordTime() {
		return recordTime;
	}
	public void setRecordTime(String recordTime) {
		this.recordTime = recordTime;
	}
	@Override
	public String toString() {
		return "Term [termId=" + termId + ", termName=" + termName + ", comment=" + comment + ", recordTime="
				+ recordTime + "]";
	}
	
	
}
