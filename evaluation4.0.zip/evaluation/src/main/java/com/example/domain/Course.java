package com.example.domain;
/**
 * @describe 课程实体类
 * @author genius
 * @Date 2019-9-22 20:15
 */
public class Course {

	private Integer courId;//课程ID
	private String  courName;//课程名称
	private String  courType;//课程类型 1：必修，2：选修
	private String  comment;//课程备注
	private String  recordTime;//记录时间
	
	public Course() {
		//系统默认无参构造
	}

	public Integer getCourId() {
		return courId;
	}

	public void setCourId(Integer courId) {
		this.courId = courId;
	}

	public String getCourName() {
		return courName;
	}

	public void setCourName(String courName) {
		this.courName = courName;
	}

	public String getCourType() {
		return courType;
	}

	public void setCourType(String courType) {
		this.courType = courType;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getRecordTime() {
		return recordTime;
	}

	public void setRecordTime(String recordTime) {
		this.recordTime = recordTime;
	}

	@Override
	public String toString() {
		return "Course [courId=" + courId + ", courName=" + courName + ", courType=" + courType + ", comment=" + comment
				+ ", recordTime=" + recordTime + "]";
	}
	
	
	
}
