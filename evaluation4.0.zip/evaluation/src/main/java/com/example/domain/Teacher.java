package com.example.domain;

/**
 * 
 * @author genius
 * @Date 2019-9-18 11:40
 * @describe 教师实体类
 */
public class Teacher {

	private Integer teaId;//教师ID
	private Integer dpId;//部门ID
	private String teaJobNumber;//教师工号
	private String teaName;//教师姓名
	private String teaPassword;//教师密码
	private String teaSex;//教师性别
	private String teaStatus;//教师状态：1、在职，2、离职
	private String isLeader;//是否领导：1、是，2、否
	private String comment;//教师信息备注
	private String recordTime;//记录时间
	
	
	
	public Teacher() {
		//默认无参构造方法
	}
	public Integer getTeaId() {
		return teaId;
	}
	public void setTeaId(Integer teaId) {
		this.teaId = teaId;
	}
	public Integer getDpId() {
		return dpId;
	}
	public void setDpId(Integer dpId) {
		this.dpId = dpId;
	}
	public String getTeaJobNumber() {
		return teaJobNumber;
	}
	public void setTeaJobNumber(String teaJobNumber) {
		this.teaJobNumber = teaJobNumber;
	}
	public String getTeaName() {
		return teaName;
	}
	public void setTeaName(String teaName) {
		this.teaName = teaName;
	}
	public String getTeaPassword() {
		return teaPassword;
	}
	public void setTeaPassword(String teaPassword) {
		this.teaPassword = teaPassword;
	}
	public String getTeaSex() {
		return teaSex;
	}
	public void setTeaSex(String teaSex) {
		this.teaSex = teaSex;
	}
	public String getTeaStatus() {
		return teaStatus;
	}
	public void setTeaStatus(String teaStatus) {
		this.teaStatus = teaStatus;
	}
	public String getIsLeader() {
		return isLeader;
	}
	public void setIsLeader(String isLeader) {
		this.isLeader = isLeader;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	public String getRecordTime() {
		return recordTime;
	}
	public void setRecordTime(String recordTime) {
		this.recordTime = recordTime;
	}
	@Override
	public String toString() {
		return "Teacher [teaId=" + teaId + ", dpId=" + dpId + ", teaJobNumber=" + teaJobNumber + ", teaName=" + teaName
				+ ", teaPassword=" + teaPassword + ", teaSex=" + teaSex + ", teaStatus=" + teaStatus + ", isLeader="
				+ isLeader + ", comment=" + comment + ", recordTime=" + recordTime + "]";
	}
	
	
	
	
	
}
