package com.example.domain;
/**
 * @describe 领带评教题库实体
 * @author 游中成
 * @date 2019年9月25日 上午10:40:41
 */
public class LeaderEvaluation {
	private int leaId;	//题目ID
	private String leaQuestion ; //题目名称
	private String esA ; //选项A
	private String esB;  //选项B
	private String esC ; //选项C
	private String esD ; //选项D
	private String comment ; //备注说明
	private String recordTime ; //录入时间
	
	
	public int getLeaId() {
		return leaId;
	}
	public void setLeaId(int leaId) {
		this.leaId = leaId;
	}
	public String getLeaQuestion() {
		return leaQuestion;
	}
	public void setLeaQuestion(String leaQuestion) {
		this.leaQuestion = leaQuestion;
	}
	public String getEsA() {
		return esA;
	}
	public void setEsA(String esA) {
		this.esA = esA;
	}
	public String getEsB() {
		return esB;
	}
	public void setEsB(String esB) {
		this.esB = esB;
	}
	public String getEsC() {
		return esC;
	}
	public void setEsC(String esC) {
		this.esC = esC;
	}
	public String getEsD() {
		return esD;
	}
	public void setEsD(String esD) {
		this.esD = esD;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getRecordTime() {
		return recordTime;
	}
	public void setRecordTime(String recordTime) {
		this.recordTime = recordTime;
	}
	
	
	

}
