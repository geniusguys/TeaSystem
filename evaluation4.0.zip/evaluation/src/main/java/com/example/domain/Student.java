package com.example.domain;

/**
 * @describe 学生实体类
 * @author genius
 * @Date 2019-9-18 11:24
 * 
 */

public class Student {

	private Integer stuId;//学生ID
	private Integer classId;//班级ID
	private String stuNumber;//学生学号
	private String stuName;//学生姓名
	private String stuPassword;//学生密码
	private String stuSex;//学生性别
	private String stuType;//学生类型：1、在校，2、休学，3、退学
	private String comment;//学生的信息备注
	private String recordTime;//记录时间字符串
	
	
	
	public Student() {
		//默认无参构造方法
	}

	public Integer getStuId() {
		return stuId;
	}
	
	public void setStuId(Integer stuId) {
		this.stuId = stuId;
	}
	
	public Integer getClassId() {
		return classId;
	}
	
	public void setClassId(Integer classId) {
		this.classId = classId;
	}
	
	public String getStuNumber() {
		return stuNumber;
	}
	
	public void setStuNumber(String stuNumber) {
		this.stuNumber = stuNumber;
	}
	
	public String getStuName() {
		return stuName;
	}
	
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	
	public String getStuPassword() {
		return stuPassword;
	}
	
	public void setStuPassword(String stuPassword) {
		this.stuPassword = stuPassword;
	}
	
	public String getStuSex() {
		return stuSex;
	}
	
	public void setStuSex(String stuSex) {
		this.stuSex = stuSex;
	}
	
	public String getStuType() {
		return stuType;
	}
	
	public void setStuType(String stuType) {
		this.stuType = stuType;
	}
	
	public String getComment() {
		return comment;
	}
	
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	public String getRecordTime() {
		return recordTime;
	}
	
	public void setRecordTime(String recordTime) {
		this.recordTime = recordTime;
	}
	
	@Override
	public String toString() {
		return "Student [stuId=" + stuId + ", classId=" + classId + ", stuNumber=" + stuNumber + ", stuName=" + stuName
				+ ", stuPassword=" + stuPassword + ", stuSex=" + stuSex + ", stuType=" + stuType + ", comment="
				+ comment + ", recordTime=" + recordTime + "]";
	}
	 
	
	 
	 
}
