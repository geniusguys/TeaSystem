/**
 * 
 */
package com.example.config;


/**
 * @author mac
 *
 */
//@Configuration
public class GlobalCorsConfig {
//    @Bean
//    public CorsFilter corsFilter() {
//        CorsConfiguration config = new CorsConfiguration();
//          config.addAllowedOrigin("*");
//          config.setAllowCredentials(true);
//          config.addAllowedMethod("*");
//          config.addAllowedHeader("*");
//          config.addExposedHeader("*");
//
//        UrlBasedCorsConfigurationSource configSource = new UrlBasedCorsConfigurationSource();
//        configSource.registerCorsConfiguration("/**", config);
//
//        return new CorsFilter(configSource);
//    }
}


